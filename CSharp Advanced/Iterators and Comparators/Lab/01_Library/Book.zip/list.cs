﻿namespace IteratorsAndComparators
{
    public class list
    {
    }
}